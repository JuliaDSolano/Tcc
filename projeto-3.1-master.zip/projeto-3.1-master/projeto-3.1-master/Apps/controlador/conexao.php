<?php

$conexao = mysqli_connect("localhost", "root", "root");
mysqli_select_db($conexao, "tcc");
?>
